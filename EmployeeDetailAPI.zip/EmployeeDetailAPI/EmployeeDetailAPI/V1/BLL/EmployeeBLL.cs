﻿using EmployeeDetailAPI.V1.Model.Response;
using System.Data.SqlTypes;
using System.Data;
using System.Net.NetworkInformation;
using EmployeeDetailAPI.V1.Model.Request;
using DataAccessLibrary;
using EmployeeDetailAPI.V1.Model.Properties;
using static DataAccessLibrary.DBAccessDapperHelper;
using StaffWelfareAPI.V1.Models.Response;

namespace EmployeeDetailAPI.V1.BLL
{
    public class EmployeeBLL
    {
        public EmployeeResponse getStaff(EmployeeRequest employeeRequest)
        {
            //DBAccessDapperHelper helper = new DBAccessDapperHelper();
            DBAccessDapperHelper dBAccessDapperHelper = new DBAccessDapperHelper();
            EmployeeResponse employeeResponse = new EmployeeResponse();
            try
            {
                string query = string.Empty;
                DataTable dt = new DataTable();


               query = "select distinct t.emp_name as EmpName, t.emp_code as Empcode,t.branch_id as Branch ,t.post_id as Postid,  t.designation_id as Designation, r.reg_id ||'--'||r.reg_name as RegionalID_Name, b.area_id ||'--'||b.area_name as AreaID_Name, z.fzm_id||'--'||z.fzm as ZoneID_Name, d.dep_id||'--'||d.dep_name as DepID_Name from mana0809.employee_master t, mana0809.region_master r, mana0809.tbl_fzm_master z, mana0809.department_mst d, mana0809.branch_dtl_new b where t.branch_id=b.branch_id and b.reg_id=z.region_id and t.department_id=d.dep_id and r.reg_id=z.region_id and t.emp_code = " + employeeRequest.Empcode + "";

                //EmployeeProperties obj = helper.GetRecord<EmployeeProperties>(query, SQLMode.Query, null);
                var employee = dBAccessDapperHelper.GetRecords<EmployeeProperties>(query, SQLMode.Query, null);
                if (employee != null)
                {
                    employeeResponse.employeeDetails = employee;
                    employeeResponse.status.code = APIStatus.success;
                    employeeResponse.status.message = "Success";
                    employeeResponse.status.flag = ProcessStatus.success;
                }
                else
                {
                    employeeResponse.status.flag = ProcessStatus.success;
                    employeeResponse.status.code = APIStatus.failed;
                    employeeResponse.status.message = "No Data Found";
                }


            }
            catch (Exception e)
            {
                employeeResponse.status.flag = ProcessStatus.failed;
                employeeResponse.status.code = APIStatus.exception;
                employeeResponse.status.message = e.Message;
            }

            return employeeResponse;
        }
    }
}
