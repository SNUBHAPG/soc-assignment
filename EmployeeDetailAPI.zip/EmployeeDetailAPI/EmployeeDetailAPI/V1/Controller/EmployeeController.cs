﻿using EmployeeDetailAPI.V1.BLL;
using EmployeeDetailAPI.V1.Model;
using EmployeeDetailAPI.V1.Model.Request;
using EmployeeDetailAPI.V1.Model.Response;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeDetailAPI.V1.Controller
{
    [Route("api/[controller]")]
    [EnableCors("Mypolicy")]
    [ApiController]
    //[Authorize]
    public class EmployeeController : ControllerBase
    {

        [HttpPost("employeedetails")]
        public ActionResult<EmployeeResponse> Post([FromBody] EmployeeRequest request)
        {
            if (ModelState.IsValid)
            {
                EmployeeBLL empBLL = new EmployeeBLL();
                return Ok(empBLL.getStaff(request));
            }
            else
            {
                return BadRequest(ModelState);
            }
        }
    }
}
