﻿namespace EmployeeDetailAPI.V1.Model.Properties
{
    public class EmployeeProperties
    {
        public string EmpName { get; set; }

        public int Empcode { get; set; }

        public string Branch { get; set; }
        public string Postid { get; set; }
        public string Designation { get; set; }
        public string RegionalID_Name { get; set; }
        public string AreaID_Name { get; set; }
        public string ZoneID_Name { get; set; }
        public string DepID_Name { get; set; }
    }
}
