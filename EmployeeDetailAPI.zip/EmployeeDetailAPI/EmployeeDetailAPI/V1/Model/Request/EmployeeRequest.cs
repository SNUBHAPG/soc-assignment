﻿namespace EmployeeDetailAPI.V1.Model.Request
{
    public class EmployeeRequest
    {
        public string Empcode { get; set; }
    }
}
