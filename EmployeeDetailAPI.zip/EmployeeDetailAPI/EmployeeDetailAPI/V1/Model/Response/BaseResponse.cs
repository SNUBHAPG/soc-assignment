﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StaffWelfareAPI.V1.Models.Response
{
    public class BaseResponse
    {
        public BaseResponse()
        {
            status = new ResponseStatus();
            status.flag = ProcessStatus.failed;
            status.code = APIStatus.failed;
            status.message = "Failed";
            status.timeStamp = DateTime.Now.ToString(Constants.Strings.dateTimeFormat);
        }
        public ResponseStatus status { get; set; }

    }


    public class ResponseStatus
    {
        public ProcessStatus flag { get; set; }
        public APIStatus code { get; set; }
        public string message { get; set; }
        public string timeStamp { get; set; }
    }
    public enum ProcessStatus
    {
        success = 1,
        failed = 0
    }

    public enum APIStatus
    {
        success = 1,
        failed = 0,
        exception = 2,
        pagenotfound = 4,
        internalexception = 5,
        invalidParameter = 6,
        invalidParameterValue = 7,
        SRM_RM_Approval_Required = 8,
        no_Data_Found = 9,
        faileTOGenerateToken = 10,
        validationFailed = 11,
        alreadyExist = 12,
        neftModificationRequired = 13,
        invalidIFSCCode = 14,
        invalidRequest = 15,
        smsRegistrationCode = 16,
        loanRejected = 17,
        badRequest = 18,
        invalidUser = 19,
        otherBranchValidation = 20,
        invalidCustomerID = 21
    }

    public class Constants
    {
        public static class Strings
        {
            public const string dateFormat = "dd-MMM-yyyy";
            public const string cashFormat = "#.00";
            public const string dateTimeFormat = "dd-MMM-yyyy hh:mm:ss";
            public const string nameFormat = @"^[a-zA-Z\s]+$";
            public const string numberFormat = "^[0-9]+$";
            public const string alphaNumericFormat = "^[a-zA-Z0-9]*$";
            public const string panNoFormat = @"^[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}$";
            public const string zeroOneFormat = "^[0-1]{0,1}$";
            public const string decimalFormat = @"^\d+.\d{0,2}$";
            public const string gl1decimalFormat = @"^\d+.\d{0,3}$";
            public const string OutStandingApprovalMode_VERIFYFORGL = "VERIFYFORGL";
            public const string OutStandingApprovalMode_SELREGFORAPPR = "SELREGFORAPPR";
            public const string schemeNameFormat = "^[A-Z]*$";
            public const string custnameFormat = @"^[a-zA-Z\s\.]+$";
        }

        public static class Ints
        {
            public const int rangeValidatorFrom_0 = 0;
            public const int rangeValidatorTo = int.MaxValue;
            public const int rangeValidatorFrom_Neg1 = -1;
            public const int rangeValidatorFrom_1 = 1;
            public const int rangeValidatorFrom_2 = 2;
            public const int rangeValidatorFrom_4 = 4;
            public const int mobileNumberLength = 10;
            public const int pinSerialLength = 6;
            public const int customerIDLength = 14;
            public const int createdBy = 7;
            public const int reportedBy = 8;
            public const int pledgeNoLength = 16;
            public const int vehicleLoanNumberLength = 22;
            public const int otpLength = 5;
            public const int inventoryitemMaxValue = 9999;
            public const int zeroOneMaxValue = 10;
            public const int messageLength = 10;
            public const int mPin = 45;
            public const int inventoryNoLength = 16;
            public const int inventoryQutaionNoLength = 16;
            public const double rangeValidatorDouble = 0.00;
            public const int branchIdLength = 4;
            public const int branchIdMaxLength = 4;
            public const int branchIdMinLength = 1;
            public const int smsmessageLength = 160;

        }
        public class InventoryValidation
        {
            public const int rangeValidatorFrom_1 = 1;
            public const int rangeValidatorFrom_2 = 2;

            public const int inventoryNo_AplphaNumeric = 16;
            public const int inventoryCharge = 5;
            public const int otherCharge = 3;
            public const int totalAmount = 6;
        }
        public class CustomerValidation
        {
            public const int customerIDLength = 14;
            public const int customerNameLength = 50;

        }
        public static class TokenStatus
        {

            public const int open = 1;
            public const int manualExpired = 0;
            public const int autoExpired = 2;
        }

        public static class LoginFlags
        {
            public const int Flag_Success = 1;
            public const int Flag_Failed = 0;
            public const int Flag_NoMobileNumber = 2;
            public const int Flag_OTP_Sent = 3;
            public const int Flag_OTP_Already_Sent = 4;
        }
    }
}
