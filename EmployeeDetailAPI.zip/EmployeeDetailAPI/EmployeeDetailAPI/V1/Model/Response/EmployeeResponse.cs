﻿using EmployeeDetailAPI.V1.Model.Properties;
using StaffWelfareAPI.V1.Models.Response;

namespace EmployeeDetailAPI.V1.Model.Response
{
    public class EmployeeResponse : BaseResponse
    {

        public List<EmployeeProperties> employeeDetails { get; set; }

    }
}
